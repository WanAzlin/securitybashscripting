#!/oah/ocqt P="confidetalybghjkmpqrsuvwxz" C="njhdafircbxoetlygkmpqsuvwz" intj `ncr ihn1.rwr| rp $P $C`>fin1.rwr #intj `ncr fin.rwr| rp $C $D`>piqsbr.rwr #intj $OUT
