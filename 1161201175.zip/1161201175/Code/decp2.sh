#!/bin/bash


P="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
C1="BGHJKMPQRSUVWXZCONFIDETALY"

echo `cat output1.txt | tr $C2 $P`>encrypted.txt

C="CONFIDETALYBGHJKMPQRSUVWXZ"

echo `cat encrypted.txt | tr $C $P`>result2.txt
