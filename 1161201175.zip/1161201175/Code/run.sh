#!/bin/bash
#usage instruction of the script
if [ $# != 1 ]
then
echo "usage: $0 <encrypted text files>"
else
echo $OUT > $0.temp
for i in {A..Z}
do
		echo -n `cat $1 |grep -o $i | wc -l` >> $0.temp
		echo " $i " >> $0.temp
done

sort -n -r $0.temp -o $0.temp
fi

