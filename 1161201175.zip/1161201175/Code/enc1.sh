#!/bin/bash

P="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
C="CONFIDETALYBGHJKMPQRSUVWXZ"

echo `cat enc1.txt| tr $P $C`>dec1.txt


