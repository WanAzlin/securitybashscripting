#!/bin/bash

P="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
C="CONFIDETALYBGHJKMPQRSUVWXZ"
C1="BGHJKMPQRSUVWXZCONFIDETALY"

echo `cat azlinstory.txt | tr $P $C`>encrypted.txt
echo `cat encrypted.txt | tr $P $C1`>output1.txt
