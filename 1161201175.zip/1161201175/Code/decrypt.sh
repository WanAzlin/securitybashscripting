#!/bin/bash

P="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
C="CONFIDETALYBGHJKMPQRSUVWXZ"

echo `cat dec1.txt | tr $C $P`>result.txt

