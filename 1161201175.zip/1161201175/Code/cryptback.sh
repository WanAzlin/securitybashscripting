#!/bin/bash

P="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
C="CONFIDETALYBGHJKMPQRSUVWXZ"

echo `cat azlinstory.txt| tr $P $C`>encrypted.txt

